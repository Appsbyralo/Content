import SwiftUI

/*
This SwiftUI view demonstrates how to use a ScrollView to display multiple images.
A ScrollView allows you to scroll through its contents vertically or horizontally.

In this example, we show three images and use different methods to resize them:

- The first image (Image1) is resized to fit a 16:9 aspect ratio and has padding on the sides.
The padding is calculated as one-ninth of the screen's width, making the image nicely centered.
 
- The second image (Image2) is resized to fit within a fixed width and height (600x400).
This method ensures the image has specific dimensions regardless of the screen size.

- The third image (Image3) is resized to fit a 16:9 aspect ratio but with a fixed width of 600.
This keeps the image at a specific width while maintaining the aspect ratio.
*/

struct ViewD: View {
    var body: some View {
        GeometryReader { geometry in
            // Define the padding for image1
            let padding = geometry.size.width / 9
            
            ScrollView {
                VStack(spacing: 20) {
                    // The size of Image1 is defined in this code: let padding = geometry.size.width / 9. the 9 defines the size of the padding on the side of the image. Here we have also defined the aspect ratio of the image to 16:9.
                    Image("Image1")
                        .resizable()
                        .aspectRatio(16/9, contentMode: .fit)
                        .padding(.horizontal, padding)
                    
                    // The size of Image2 is defined in the .frame line. change the width and height to ajust it to what you need.
                    Image("Image2")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 600, height: 400)
                    
                    // The Size of Image3 is define only by the width of the image, but we have defined that it should be in a 16:9 format.
                    Image("Image3")
                        .resizable()
                        .aspectRatio(16/9, contentMode: .fit)
                        .frame(width: 600)
                }
            }
        }
    }
}

struct ViewD_Previews: PreviewProvider {
    static var previews: some View {
        ViewD()
    }
}
