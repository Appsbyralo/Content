import SwiftUI
import PlaygroundSupport

struct ContentView: View {
    var body: some View {
        TabView {
            ViewA()
                .tabItem {
                    Image(systemName: "phone.fill")
                    Text("Insert Photo")
                }
            ViewB()
                .tabItem {
                    Image(systemName: "eraser.fill")
                    Text("Insert link")
                }
            ViewC()
                .tabItem {
                    Image(systemName: "book.fill")
                    Text("Insert video")
                    
                }
            ViewD()
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Scroll View")
                }
        }
    }
}
