import SwiftUI 
import AVKit 


struct ViewC: View {
    // This line creates a video player that will play a video file named "Burger.mp4" from our app's main folder
    let avPlayer = AVPlayer(url: Bundle.main.url(forResource: "Burger", withExtension: "mp4")!)
    
    var body: some View {
        // GeometryReader lets us get the size of the screen
        GeometryReader { geometry in
            // Calculate padding as 1/8 of the screen width. 
            // .padding adds space around a view to make it look less cramped and more organized
            let padding = geometry.size.width / 8
            // Calculate the width of the video to be the screen width minus the padding on both sides
            let videoWidth = geometry.size.width - (2 * padding)
            // Calculate the height of the video to keep the 4:3 aspect ratio (4 units wide, 3 units tall)
            let videoHeight = videoWidth * (3/4)
            
            // Create a video player that plays the video we set up above
            VideoPlayer(player: avPlayer)
            // Keep the video in a 4:3 shape (like an old TV) no matter how big or small we make it
                .aspectRatio(4/3, contentMode: .fit)
            // Set the width and height of the video
                .frame(width: videoWidth, height: videoHeight)
            // Center the video in the middle of the screen
                .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
        }
    }
}


struct ViewC_Previews: PreviewProvider {
    static var previews: some View {
        ViewC() 
    }
}
