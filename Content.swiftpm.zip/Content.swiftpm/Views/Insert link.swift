import SwiftUI

struct ViewB: View {
    
    // It's like having a special helper that can open URLs (web addresses)
    @Environment(\.openURL) var openURL
    
    var body: some View {
        VStack {
            Spacer()
            
            // The Button
            Button(action: {
                // This action is performed when the button is tapped
                if let url = URL(string: "https://www.visitcopenhagen.com/copenhagen/eat-drink/best-burgers-copenhagen") {
                    // If the URL is valid, open the web page
                    openURL(url)
                }
            }) {
                // The text inside the button
                Text("Visit a burger joint in Copenhagen")
                    .foregroundColor(.white) // Makes the text color white
                    .padding() // Adds some padding around the text
                    .frame(width: 300, height: 300) // Sets the size of the button
                    .background(Circle().fill(Color.black)) // Makes the button a blue circle
            }
            
            Spacer()
        }
    }
}

struct ViewB_Previews: PreviewProvider {
    static var previews: some View {
        ViewB()
    }
}
