import SwiftUI

struct ViewA: View {
    var body: some View {
             Image("Image1")
            .resizable()
            .aspectRatio(contentMode: .fit)
    }
}
struct ViewA_Previews: PreviewProvider {
    static var previews: some View {
        ViewA()
    }
}
