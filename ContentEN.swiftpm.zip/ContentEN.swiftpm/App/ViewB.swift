import SwiftUI

struct ViewB: View {
    
    /*#-code-walkthrough(VB.2)*/
    @Environment(\.openURL) var openURL
    /*#-code-walkthrough(VB.2)*/
    var body: some View {
        VStack {
            Spacer()
            
            /*#-code-walkthrough(VB.3)*/
            Button(action: {
               
                if let url = URL(string:
                    /*#-code-walkthrough(VB.4)*/
                "https://education.apple.com/learning-center/T021339A?backTo=%2Flearning-center")
                /*#-code-walkthrough(VB.4)*/{
                    openURL(url)
                    /*#-code-walkthrough(VB.4)*/
                    /*#-code-walkthrough(VB.3)*/
                }
            }) {
                /*#-code-walkthrough(VB.5)*/
                Text("Apple Page on coding with Swift")
                /*#-code-walkthrough(VB.5)*/
                /*#-code-walkthrough(VB.6)*/
                    .foregroundColor(.white) // Makes the text color white
                    .frame(width: 300, height: 300) // Sets the size of the button
                    .background(Circle().fill(Color.blue)) // Makes the button a blue circle
                /*#-code-walkthrough(VB.6)*/
            }
            
            Spacer()
        }
    }
}

struct ViewB_Previews: PreviewProvider {
    static var previews: some View {
        ViewB()
    }
}



